<?php 
define("HOST", "localhost");   
define("USER", "infinitybusiness_mrk941177");  
define("PASSWORD", "5Relas#l+o?N");    
define("DATABASE", "infinitybusiness_mrk941177");  
 
define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "member");
 
define("SECURE", FALSE);    

 ?>